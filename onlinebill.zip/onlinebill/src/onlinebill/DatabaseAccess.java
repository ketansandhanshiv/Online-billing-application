package onlinebill;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;
 
/**
 * Servlet implementation class DatabaseAccess
 */
@WebServlet("/DatabaseAccess")
public class DatabaseAccess extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public DatabaseAccess() {
        super();
        // TODO Auto-generated constructor stub
    }
	
	Connection conn;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		 String phn_no=request.getParameter("phn");
		
	      // JDBC driver name and database URL
	      final String JDBC_DRIVER="com.mysql.jdbc.Driver";  
	      final String DB_URL="jdbc:mysql://localhost/BSNL";

	      //  Database credentials
	      final String USER = "root";
	      final String PASS = "root";

	      // Set response content type
	      response.setContentType("text/html");
	      PrintWriter out = response.getWriter();
	      String title = "BSNL HOME";
	      
	      try{
	         // Register JDBC driver
	         Class.forName(JDBC_DRIVER);

	         // Open a connection
	         conn = DriverManager.getConnection(DB_URL, USER, PASS);

	         // Execute SQL query
	         
	         String sql = "SELECT * FROM customer where mobile=?";
	         PreparedStatement pst=conn.prepareStatement(sql);
	         pst.setString(1, phn_no);
	         
	         ResultSet rs = pst.executeQuery();

	         // Extract data from result set
	         while(rs.next()){
	            //Retrieve by column name
	            //int phn  = rs.getInt("mobile");
	            int bill1 = rs.getInt("bill");
	            String name1 = rs.getString("name");
	            
        
	         
	         out.println("<html>\n" +
	     	         "<head><title>" + title + "</title></head><form action='payBill' method ='POST'>\n" +
	     	         "<body bgcolor=\"lightblue\"><br><br><h2><center>Welcome to BSNL Bill portal</center>\n" +
	     	         "<h5 align=\"center\">Hello " + name1 + " Sir, </h1>\n<br>");	         
	         out.println("</body></html>");
	         out.println("Customer name : <input type = 'text' value="+name1+" name='name2'> <br><br>");
	        out.println("Phone number : <input type = 'text' value="+phn_no+" name='phn_no1'> <br><br>");
	 		out.println("Bill : <input type ='text' value="+bill1+" name='bill2'> <br><br>");
	 		out.println("<button input type='submit' onclick='windows.location.href='http://localhost:8080/firstweb/payBill' value='submit'>Pay</button>");
			out.println("<button input type='reset' value='reset'>Reset</button>");
			

	         // Clean-up environment
	         rs.close();
	         conn.close();
	         }
	      }catch(SQLException se){
	         //Handle errors for JDBC
	         se.printStackTrace();
	      }catch(Exception e){
	         //Handle errors for Class.forName
	         e.printStackTrace();
	      }finally{
	         //finally block used to close resources
	         try{
	            if(conn!=null)
	            conn.close();
	         }catch(SQLException se){
	            se.printStackTrace();
	         }//end finally try
	      } //end try

	}

}
