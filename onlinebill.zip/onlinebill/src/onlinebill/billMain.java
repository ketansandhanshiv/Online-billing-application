package onlinebill;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class billMain
 */
@WebServlet("/billMain")
public class billMain extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public billMain() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("Text/html");
		PrintWriter out =response.getWriter();
		out.println("<html><body bgcolor='lightblue'>  <title>ONLINE TELEPHONE BILL PAYMENT</title> <h4><center>WELCOME TO BSNL</center> <center><form action='DatabaseAccess' method ='POST'><br><br>");
		out.println("TELEPHONE NUMBER --> <input type = 'text' name= 'phn'/> <br><br>");
		
		out.println("<button input type='submit' onclick='windows.location.href='http://localhost:8080/firstweb/DatabaseAccess' 'value='signin'>Submit</button>");
		out.println("<button input type='reset' value='reset'>Reset</button>");
		out.println("</form></center></body></html>");

	}

}
