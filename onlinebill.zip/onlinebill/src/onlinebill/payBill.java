package onlinebill;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class payBill
 */
@WebServlet("/payBill")
public class payBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	DatabaseAccess da=new DatabaseAccess();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public payBill() {
        super();
        // TODO Auto-generated constructor stub
    }
	Connection conn;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
	doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String name1=request.getParameter("name2");
		String phn_no=request.getParameter("phn_no1");
		String bill1=request.getParameter("bill2");
		
		final String JDBC_DRIVER="com.mysql.jdbc.Driver";  
	      final String DB_URL="jdbc:mysql://localhost/BSNL";

	      //  Database credentials
	      final String USER = "root";
	      final String PASS = "root";

	      // Set response content type
	      //response.setContentType("text/html");
	      
	      try{
	         // Register JDBC driver
	         Class.forName(JDBC_DRIVER);

	         // Open a connection
	         conn = DriverManager.getConnection(DB_URL, USER, PASS);

	         // Execute SQL query
	         
	         String sql = "UPDATE customer SET bill=?-? WHERE mobile=? ";
	         PreparedStatement pst=conn.prepareStatement(sql);
	         pst.setString(3, phn_no);
	         pst.setString(1, bill1);
	         pst.setString(2, bill1);
	         pst.executeQuery();

	         
	    		response.setContentType("Text/html");
	    		PrintWriter out1 =response.getWriter();
	    		out1.println("<html><body bgcolor='lightblue'>  <title>ONLINE TELEPHONE BILL PAYMENT</title> <h4><center>WELCOME TO BSNL</center> <center><form method ='POST'><br><br>");
	    		out1.println("Welcome "+name1+" Sir, <br><br>");
	    		out1.println("Your bill is Successfully Paid <br><br>");
	    		
	    		out1.println("<button input type='submit' 'value='submit'>Submit</button>");
	    		out1.println("</form></center></body></html>");
			

	         // Clean-up environment
	         
	         conn.close();
	      }catch(SQLException se){
	         //Handle errors for JDBC
	         se.printStackTrace();
	      }catch(Exception e){
	         //Handle errors for Class.forName
	         e.printStackTrace();
	      }finally{
	         //finally block used to close resources
	         try{
	            if(conn!=null)
	            conn.close();
	         }catch(SQLException se){
	            se.printStackTrace();
	         }//end finally try
	      } //end try
	}

}
